/*
 * lab_1.h
 *
 *  Created on: Sep 25, 2019
 *      Author: akhanifa
 */

#ifndef LAB_1_H_
#define LAB_1_H_


#include "system.h"
#include "alt_types.h"
#include <stdio.h>
#include <unistd.h>
#include "system.h"
#include "priv/alt_legacy_irq.h"
#include "sys/alt_irq.h"
#include "altera_avalon_pio_regs.h"


#endif /* LAB_1_H_ */
